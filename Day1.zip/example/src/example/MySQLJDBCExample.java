package example;
import java.sql.Connection;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.DriverManager;
import java.sql.SQLException;


public class MySQLJDBCExample {
	
	    static Connection connection = null;
	    static Statement statement = null;
	     static ResultSet result = null;

	    public static void main(String[] args) throws SQLException {
	        try {
	            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/practice", "root", "root");
	            Statement statement = connection.createStatement();
	            ResultSet result = statement.executeQuery("SELECT * FROM table1");
	        
	       while (result.next())
	        	{
	        	
	        	System.out.print(result.getString(1)+ " ");
	        	System.out.print(result.getString(2)+ " ");
	        	System.out.print(result.getString(3)+ " ");
	        	System.out.print(result.getString(4));
	        	System.out.println(" ");
	        }
	        }catch (SQLException e) {
	        	e.printStackTrace();
	        }
	        finally {
	        	try {
	        		if(result != null)
	        			result.close();
	        		if(statement != null)
	        			statement.close();
	        		if (connection != null)
	        			connection.close();
	        	} catch (SQLException e) {
		        	e.printStackTrace();
		        }
	        }
		
	
		
		
		
		
	}
	
}

