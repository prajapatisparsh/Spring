package example;
import java.sql.Connection;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;


public class example1 {

static Connection connect = null;
static PreparedStatement pst = null;
static ResultSet result = null;
static Scanner sc = null;
//
//void connection() throws SQLException {
//}
 
public void DisplayMenu() throws SQLException {
	sc =  new Scanner(System.in);
	
	 System.out.println("1:Register User \n" + 
	 "2:List All User based on City \n" +
	 "3:Update Password of a User \n" +
	 "4:Display user information based on User Name \n" + 
	 "5: Exit ");
	 int choose = sc.nextInt();
	 switch (choose) {
	 case 1 : RegisterUser();break;
	 case 2 : ListCity();break;
	 case 3 : PaswordUpdate();break;
	 case 4 : InfoUserName();break;
	 case 5 : CloseConnection();return;
	 default : System.out.println("Invalid choice");
	 return;
	 }
 }
//case 1 : RegisterUser();break;
public void RegisterUser() throws SQLException {
	System.out.println("Enter unique username :");
	String userName = sc.next();
	System.out.println("Enter Your name :");
	String name = sc.next();
	System.out.println("Enter password:");
	String password = sc.next();
	System.out.println("Enter your email id :");
	String email = sc.next();
	System.out.println("Enter your city");
	String city = sc.next();		
	
	String query = "INSERT INTO  table1 (userName,name,password,email,city) VALUES (?,?,?,?,?)";
    pst = connect.prepareStatement(query);
    pst.setString(1, userName);
    pst.setString(2, name);
    pst.setString(3, password);
    pst.setString(4, email);
    pst.setString(4, city);

    System.out.println("User registered");
}
//case 2 : ListCity();break;
public void ListCity() throws SQLException {
	System.out.println("Enter City name :");
	String city = sc.next();
	System.out.println("Users form city : " + city );
	
	String query = "SELECT * FROM table1 WHERE city = ?";
	pst = connect.prepareStatement(query);
	pst.setString(1, city);
	result = pst.executeQuery();
	
	while(result.next()) {
		System.out.println("Username:" +result.getString("userName") 
		+ "\n Name:" + result.getString("name")
		+"\n Email:" + result.getString("email"));
	}
			
}
//case 3 : PaswordUpdate();break;
public void PaswordUpdate() throws SQLException{
	System.out.println("Enter username:");
	String userName = sc.next();
	System.out.println("Enter new password:");
	String password = sc.next();
String query = "UPDATE table1 SET password = ?  where userName = ? ";
	pst = connect.prepareStatement(query);
	pst.setString(1, password);
	pst.setString(2, userName);
	
	int updatepass = pst.executeUpdate();
if (updatepass> 0 ) {System.out.println("Password succesfully updated");}
else {System.out.println("Invalid username");}
}
//case 4 : InfoUserName();break;
public void InfoUserName() throws SQLException {
	System.out.println("Enter username:");
	String userName = sc.next();
	String query = "SELECT * FROM table1 WHERE userName = ?";
	pst = connect.prepareStatement(query);
	pst.setString(1, userName);
	result = pst.executeQuery();
if(result.next()) {
	System.out.println("Username:" +userName+"\n Name:" + result.getString("name") + "\n email:" + result.getString("email") + "\n city:" + result.getString("city")  );}
else {System.out.println("Username doesnt exist");}
}

//case 5 : CloseConnection();return;
public void CloseConnection() throws SQLException{
	   try {
	        if (result != null) result.close();
	        if (pst != null) pst.close();
	      
	        if (connect != null) connect.close();

	        System.out.println("Connection closed successfully");
	    } catch (SQLException e) {
	        System.out.println("Error while closing connection: " + e.getMessage());
	    }
	

}

public static void main (String[] args) throws SQLException {
	try {
		connect = DriverManager.getConnection("jdbc:mysql://localhost:3306/practice", "root", "root");
		System.out.println("Connection Successfull");
		
		new example1().DisplayMenu();

	}finally {}
	
	
}
}
