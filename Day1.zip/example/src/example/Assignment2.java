package example;
import java.sql.Connection;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;


public class Assignment2 {
    static Connection connect = null;
    static PreparedStatement pst = null;
    static ResultSet result = null;
    static Scanner sc = new Scanner(System.in);
   public void DisplayMenu() throws SQLException {
	  while (true) {
	   System.out.println("*************Menu*************");
	   System.out.println("1.Create Table"+
	   "\n 2.Display Columns of Table " +
	   "\n 3.Exit");
	   System.out.println("Enter Your Choice");
	   int choice = sc.nextInt();  
	   sc.nextLine();
	   switch (choice) {
	   case 1: CreateTable();break;
	   case 2: DisplayTables();break;
	   case 3 : CloseConnections();return;
	   default: System.out.println("Invalid Input");
	   }}
   }
   

//   case 1: CreateTable();break;
   private void CreateTable() {
	   System.out.println("Enter table name: ");
       String tableName = sc.nextLine();
	  
       StringBuilder createQuery = new StringBuilder("CREATE TABLE" + tableName + "(");
       boolean primaryKeySet = false; 
	   
       while (true) {
       System.out.println("i. Add Column" + 
      "ii. SetPrimary Key" +
	  "iii. Save");
	   String choice = sc.next();
	   sc.nextLine();
	   switch(choice.toLowerCase()) {
	   case "i": System.out.println("Enter Column name :");
		        String column = sc.next();
		        
		   System.out.println("Choose Data type \n1.VARCHAR \n2. INT \n3.FLOAT");
		   int typechoice = sc.nextInt();
		   String dataType;
		   switch (typechoice) {
		   case 1: dataType = "VARCHAR(45)";break;
		   case 2: dataType = "INT" ;break;
		   case 3: dataType = "FLOAT";break;
		   default: System.out.println("Invalid input bsdk");
			    return;
			    }
		   if (createQuery.toString().endsWith("(")) {
			   createQuery.append(column).append(" ").append(dataType);
			   }else {createQuery.append(", ").append(column).append(" ").append(dataType);	   
		   }
		   
		    break;
	   case "ii": 
		   if (primaryKeySet) {System.out.println("Primary key already Set");
		   break; 
		   }
		   System.out.println("Enter Column Name to set a primary key:");
		   String pkColumn = sc.next();
		   createQuery.append(",PRIMARY KEY (").append(pkColumn).append(")");
		   primaryKeySet = true;
		   System.out.println("Primary key set to " + pkColumn);
		   break;
	   case "iii":
		   createQuery.append(");");
           try (PreparedStatement pst = connect.prepareStatement(createQuery.toString())) {
               pst.executeUpdate();
               System.out.println("Table " + tableName + " created successfully.");
           } catch (SQLException e) {
               System.out.println("Error creating table: " + e.getMessage());
           }
           return;

       default:
           System.out.println("Invalid choice. Please try again.");
   }
	   }
   }
   
//   case 2: DisplayTables();break;
   private void DisplayTables() throws SQLException {
	   System.out.println("Enter table name to be displayed:");
	   String tableName = sc.next();
	   
	   try {
	       // Much simpler query to get column names
	       String query = "DESCRIBE " + tableName;
	       
	       pst = connect.prepareStatement(query);
	       result = pst.executeQuery();
	       
	       System.out.println("Columns of table " + tableName + ":");
	       
	       while (result.next()) {
	           // This will print the column name (first column in DESCRIBE result)
	           System.out.println(result.getString(1));
	       }
	   } catch (SQLException e) {
	       System.out.println("Error retrieving table columns: " + e.getMessage());
	   }
	}
   
//   case 3 : CloseConnections();return;
   private void CloseConnections() {
	   try {
           if (result != null) result.close();
           if (pst != null) pst.close();
           if (connect != null) connect.close();
           sc.close();
           System.out.println("Connections closed successfully.");
       } catch (SQLException e) {
           System.out.println("Error closing connections: " + e.getMessage());
       }
   }
//   default: System.out.println("Invalid Input");
//   }
    
	 public static void main (String[] args) throws SQLException {
    	 try { 
    		 connect = DriverManager.getConnection("jdbc:mysql://localhost:3306/practice", "root", "root");
    			System.out.println("Connection Successfull");
    		 new Assignment2().DisplayMenu();
    	 }finally {}
     }
}
