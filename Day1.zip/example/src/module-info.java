/**
 * 
 */
/**
 * 
 */
module example {
	requires java.sql;
}