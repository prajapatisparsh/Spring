
show databases;
# Create a new user
CREATE USER 'javadatabase'@'localhost' IDENTIFIED BY 'password123';
create table my;
# Grant privileges to the new user
GRANT ALL PRIVILEGES ON table_creator_db.* TO 'javadatabase'@'localhost';

# Flush privileges to ensure changes take effect
FLUSH PRIVILEGES;

-- Check existing users
SELECT User, Host FROM mysql.user;

-- Create user with explicit localhost permissions
CREATE USER 'javadatabase'@'localhost' IDENTIFIED BY 'password123';
GRANT ALL PRIVILEGES ON table_creator_db.* TO 'javadatabase'@'localhost';
FLUSH PRIVILEGES;

-- Alternative: Create user with wildcard host
CREATE USER 'javadatabase'@'%' IDENTIFIED BY 'password123';
GRANT ALL PRIVILEGES ON table_creator_db.* TO 'javadatabase'@'%';
FLUSH PRIVILEGES;

-- Show authentication method
SELECT user, host, plugin FROM mysql.user;

-- If using older authentication, might need to alter
ALTER USER 'javadatabase'@'localhost' 
IDENTIFIED WITH mysql_native_password BY 'password123';
FLUSH PRIVILEGES;